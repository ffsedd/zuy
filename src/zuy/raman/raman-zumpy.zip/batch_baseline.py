#!/usr/bin/env python3

import matplotlib.pyplot as plt
import sys
from zumpy.ir.jdx import Jdx
from zumpy.qq.spectrum.spectrum import Spectrum
from pathlib import Path
# -------------------------------------------------



indir = Path(".")
inexts = ".csv .txt .jdx".split()   

fps = (f for f in indir.glob("*.*") if f.suffix.lower() in inexts)
spectra = ( Jdx(f) for f in fps )

# convert and plot all
for s in spectra:
    s.baseline_correction()
    s.save()

    
    
