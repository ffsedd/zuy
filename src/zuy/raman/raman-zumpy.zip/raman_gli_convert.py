#!/usr/bin/env python3
'''
'''
from pathlib import Path
from zumpy.qq.spectrum.spectrum import RamanSpectrum, Spectrum
from zumpy.ir.jdx import Jdx
from pprint import pprint

ROOT = Path().resolve()  # current dir - ./2034v1/spec.csv  ./2034v1/standardy/anatas.jdx
SPEC_EXTS = ['.csv','.txt']  




def main():
    
    fs = sorted(f for f in ROOT.rglob("*.*") if f.suffix in SPEC_EXTS)
    pprint(fs)

    # convert all files recursivelly
    for f in fs:
        print(f)
        try:
            s = RamanSpectrum(path=f)
            s.datatype = "RAMAN SPECTRUM"
            s.title = s.path.stem
            s.xunits = '1/CM'
            s.yunits = 'INTENSITY'
            s.baseline_correction()
            s.smooth()
            s.save(s.path.with_suffix(".jdx"))  # save as jdx
            
            dpath = f.parent / "orig"
            dpath.mkdir(exist_ok=True)
            f.rename(dpath / (f.name + ".bak"))
        except ValueError as e:
            print(f"Spectrum conversion failed: {f}")
            print(f"Error: {e}")
            



    
    
    
    
    
    
        
if __name__ == "__main__":
    main()
    
    
