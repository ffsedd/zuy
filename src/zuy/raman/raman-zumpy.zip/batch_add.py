#!/usr/bin/env python3

import matplotlib.pyplot as plt
import sys
from zumpy.qq.ntool.smooth import smooth_golay
from zumpy.ir.jdx import Jdx
from pathlib import Path
# -------------------------------------------------



indir = Path(".")

inexts = ".csv .txt .jdx".split()   

fps = [f for f in indir.glob("*.*") if f.suffix.lower() in inexts and f.stem != "sum"]

# load spectra
spectra = [ Jdx( filepath=f ) for f in fps ]
print("spectra",  spectra)

# convert and plot all
for s in spectra:
    s.baseline_correction()
    s.datatype="RAMAN SPECTRUM"
    s.plot()

s2 = s
s2.y = sum(s.y for s in spectra)
s2.y = smooth_golay(s2.y, window_size=71, order=2, deriv=0, rate=1)
s2.plot()

plt.show()    

# save all as jdx

s2.save("sum.jdx")

    
    
