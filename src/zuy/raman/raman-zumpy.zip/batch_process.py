#!/usr/bin/env python3

from zumpy.qq.ntool.smooth import smooth_golay
from zumpy.ir.jdx import Jdx
from pathlib import Path
from pprint import pprint
# -------------------------------------------------



def parse_args():
    import argparse
    from pathlib import Path
    p = argparse.ArgumentParser(description=f'{__doc__} path:{Path(__file__).resolve()}',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('-s','--smooth', default=0, type=int, help="smooth window - odd int")
    p.add_argument('-m','--multiply', default=1, type=float, help="multiply - float")
    p.add_argument('-b','--baseline', action='store_true', default=False)
    p.add_argument("-v", "--verbose", action="count", default=0,
        help="verbose (CRITICAL, ERROR, WARN, INFO, DEBUG), eg. -vvvv")
    p.add_argument('-d', '--indirs', default=[], help='list of input dirs', required=False, nargs='+', type=str)
    p.add_argument('-f', '--infiles', default=[], help='list of input files', required=False, nargs='+', type=str)
    p.add_argument('-x', '--extensions', default=[], help='list of exentsions', required=False, nargs='+', type=str)
    p.add_argument('-r', '--recursive', required=False, default=False, action='store_true')
    args = p.parse_args()
    return args



def main():
    args = parse_args()
    print("batch process spectra", locals())
    
    infiles=args.infiles
    
    for d in sorted(args.indirs):
        infiles += get_files(d, **vars(args))
            
    batch_process_spectra(fpaths=infiles, **vars(args))    

def get_files(dpath, extensions=None, recursive=False, *a, **kw):
    
    if recursive:
        fps = sorted(Path(dpath).rglob("*.*"))
    else:
        fps = sorted(Path(dpath).glob("*.*"))
    if extensions:
        exts = [e.lstrip(".") for e in extensions]
        fps = [f for f in fps if f.suffix.lstrip(".") in exts]
    pprint(fps)       
    return fps    

def batch_process_spectra(fpaths, smooth=None, baseline=None, multiply=None, *a, **kw):

    for fp in fpaths:
        print(fp)
        s = Jdx( filepath=fp )
        if baseline:
            s.baseline_correction()
        if smooth:    
            s.y = smooth_golay(s.y, window_size=smooth, order=2, deriv=0, rate=1)
        if multiply:
            s.y = s.y * multiply    
        s.save()

        

    
    
    
        
if __name__ == "__main__":
    main()
