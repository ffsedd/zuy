#!/usr/bin/env bash 
x-terminal-emulator -e bash -c 'jupyter notebook jdx.ipynb'
