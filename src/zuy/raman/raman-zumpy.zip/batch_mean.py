from zumpy.qq.spectrum.spectrum import Spectrum
from pathlib import Path
import matplotlib.pyplot as plt

fs = sorted(Path().glob("*casova*.jdx"))
print(fs)
 
ss = [Spectrum(f) for f in fs]
print(ss)
sm = None
for s in ss:
    if not sm:
        sm = s
    else:
        sm.y = sm.y + s.y
sm.y = sm.y / len(ss)        
print(sm.y)         
# ~ sm.plot()   
# ~ plt.show()
sm.save(fs[0].name+"_sum.jdx")
