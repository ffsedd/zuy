#!/usr/bin/env python3
'''
'''

from pathlib import Path
from zumpy.qq.spectrum.spectrum import Spectrum 
from bs4 import BeautifulSoup
import pandas as pd
import requests
import re
import json
from string import Template
from matplotlib import pyplot as plt
from pprint import pprint

URL_BASE = "http://www.irug.org"
INDEX_URL = "/search-spectral-database/spectra-index"
index_path = Path("spectra-index.xlsx")
done_path = Path("downloaded.txt")
failed_path = Path("failed.txt")


HEADER = {
        "TITLE":"",
        "XUNITS":"",
        "YUNITS":"",
        "SIGNALTYPE":"",
        "DATATYPE":"",
        "DATE":"",
        "SAMPLING PROCEDURE":"",
        "ORIGIN":"",
        "OWNER":"",
        "DATA PROCESSING":"",
        "SPECTROMETER/DATA SYSTEM":"",
                  }

def main():
        
    # GET INDEX
    if index_path.is_file():
        print("open downloaded index")
        df = pd.read_excel(index_path).fillna("")
    else:    
        html = download_html(URL_BASE+INDEX_URL)    
        df = parse_irug_spectral_index(html)
        df.to_excel(index_path, index=False)
        
    if not done_path.is_file():
        done_path.write_text("")    
    done = done_path.read_text().split()   
    
    
    # DOWNLOAD SPECTRA    
    for index, row in df.iterrows():
        print(row.Code, row.Type, row.CommonName, row.Link, end=" ")
        
        if row.Code in done:
            continue
        
        url = row.Link
        try:
            h, data = parse_irug_spectrum(url)
        except ValueError:
            with open(failed_path, "a") as f:
                f.write(row.Code + "\n")
            with open(done_path, "a") as f:
                f.write(row.Code + "\n")   
            continue     
        # ~ print(h, data)
        
        h["DATATYPE"] = row.Type.replace("IR", "INFRARED SPECTRUM").replace("Raman", "RAMAN SPECTRUM")
        h["ORIGIN"] = url
        
        sp = Spectrum(data=data, header=h)
        fname = row.Code.split(" ")[0] + " " + row.CommonName + ".jdx"
        if not fname:
            fname = h["SAMPLE DESCRIPTION"]
        fname = fname.replace("β","b").replace("α", "a").replace("ε", "e").replace(":","+") 
        fname = slugify(fname)
        print("saved: ", fname)
        sp.save(fname)
        
        with open(done_path, "a") as f:
            f.write(row.Code + "\n")

    
def download_html(url):

    response = requests.get(url)
    if response.status_code == 200:
        return response.text


def parse_irug_spectral_index(html):

    soup = BeautifulSoup(html, 'html.parser')
    # Find all table rows
    rows = soup.find_all('tr')
    # Extract data from rows
    data = []
    for row in rows:
        cells = row.find_all('td')
        if cells:
            data.append({
                'Code': cells[0].text.strip(),
                'Type': cells[1].text.strip(),
                'CommonName': cells[2].text.strip(),
                'TradeName': cells[3].text.strip(),
                'MaterialClass': cells[4].text.strip(),
                'ContributingInstitutionAcronym': cells[5].text.strip(),
                'Link': URL_BASE + cells[6].a['href'].strip() if cells[6].a else None
            })
    # Create DataFrame
    df = pd.DataFrame(data)
    return df




def parse_irug_spectrum(url):
    
    html = download_html(url)
    soup = BeautifulSoup(html, 'html.parser')
    script_tag = soup.find('script', {'type': 'text/javascript'})
    try:

        script_content = script_tag.string

        # Extract title
                    
        header_str = re.search(r"var jqPlotOptions = ({.*?});", script_content, re.DOTALL).group(1)
        header = js_object_to_dict(header_str)

        
        # Extract spectral data
        spectral_data_str = re.search(r"jqPlotData\.series\['Submitter'\] = ({.*?});", script_content, re.DOTALL).group(1)
        data_dict = eval(spectral_data_str)
        
        # ~ print("header:", header)
        # ~ print("Spectral Data:", data_dict)
        
    except Exception as e:
        raise ValueError(f"Error parsing spectrum data from {url}: {e}")
    
    # Convert dictionary to Pandas Series
    data_series = pd.Series(data_dict)
    data_series.index = data_series.index.astype(float)  # Convert index to float
    data_series.index.name = 'x'
    data_series.name = 'y'

    h = HEADER.copy()
    h["TITLE"] = header["title"]
    h["XUNITS"] = header["axes"]["xaxis"]["label"].replace("Wavenumbers (cm-1)", "1/CM")
    h["YUNITS"] = header["axes"]["yaxis"]["label"]

    # ~ print(header["axes"]["xaxis"]["label"], h["XUNITS"])
    # Find the table containing the details
    details_table = soup.find('table', class_='table-bordered')

    # Define a dictionary to store the parsed values
    parsed_values = {}

    # Find and parse all cells in the table
    for row in details_table.find_all('tr'):
        cells = row.find_all('td')
        for cell in cells:
            label = cell.find('div', class_='strong')
            if label:
                label_text = label.text.strip().strip(":")
                value_text = label.find_next_sibling('div').text.strip()
                parsed_values[label_text] = value_text
    # ~ pprint(parsed_values)

    # JDX FIELDS
    h["SAMPLE DESCRIPTION"] = parsed_values.get('Chemical/botanical name(s)', '')
    h["NAMES"] = parsed_values.get('Common name(s)', '')
    h["CAS NAME"] = parsed_values.get('CAS name', '')
    h["CAS REGISTRY NO"] = parsed_values.get('CAS registry no', '')
    h["SPECTROMETER/DATA SYSTEM"] = parsed_values.get('Application', '')
    h["SAMPLING PROCEDURE"] = parsed_values.get('Mode', '').replace("Tran", "TRANSMISSION").replace("Scat", "SCATTERING").replace("Refl", "REFLECTANCE")
    h["MOLFORM"] = parsed_values.get('Molecular formula', '')
    # CUSTOM FIELDS
    h["COLOR"] = parsed_values.get('Color', '')
    h["LASER"] = parsed_values.get('Excitation source (nm)', '')
    h["COMMENTS"] = str(parsed_values)
    
    return h, data_series    

        
def js_object_to_dict(js_content):
    js = re.sub(r' +(\w+): ',  r"'\1': ", js_content)
    js = js.replace("false", "False")
    js = js.replace("true", "True")
    parsed_dict = eval(js)
    return parsed_dict    
    

def slugify(filename):
    return "".join( x for x in filename if (x.isalnum() or x in ",._- ()#@%&!"))

    
        
if __name__ == "__main__":
    main()
