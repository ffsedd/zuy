#!/usr/bin/env python3
'''
'''

from pathlib import Path
from zumpy.qq.spectrum.spectrum import Spectrum 
from bs4 import BeautifulSoup
import pandas as pd
import requests
import re
import json
from string import Template
from matplotlib import pyplot as plt
from pprint import pprint

URL_BASE = "https://soprano.kikirpa.be"
INDEX_URL = "/index.php?lib=sop"

index_path = Path("soprano-spectra-index.xlsx")
done_path = Path("downloaded.txt")
failed_path = Path("failed.txt")


HEADER = {
        "TITLE":"",
        "XUNITS":"",
        "YUNITS":"",
        "SIGNALTYPE":"",
        "DATATYPE":"",
        "DATE":"",
        "SAMPLING PROCEDURE":"",
        "ORIGIN":"",
        "OWNER":"",
        "DATA PROCESSING":"",
        "SPECTROMETER/DATA SYSTEM":"",
                  }

def main():
        
    # GET INDEX
    if index_path.is_file():
        print("open downloaded index")
        df = pd.read_excel(index_path).fillna("")
    else:    
        html = download_html(URL_BASE+INDEX_URL)    
        df = parse_index(html)
        df.to_excel(index_path, index=False)

    download_spectra(df)
    
def download_spectra(df):    
    # DOWNLOAD SPECTRA    
            
    if not done_path.is_file():
        done_path.write_text("")    
    done = done_path.read_text().split()   
    onclick_urls = []
    for index, row in df.iterrows():
        print(row.url, end=" ")

        
        url = row.url
        if url in done:
            continue
        html = download_html(url)
        soup = BeautifulSoup(html, 'html.parser')
        # Find all divs with class "field"
        field_divs = soup.find_all('div', class_='field')

        # Extract onclick URL from divs containing the specified span
        
        for div in field_divs:
            anchor_tag = div.find('a')
            span_tag = div.find('span', text='JCAMPDX (.dx)')
            if anchor_tag and span_tag:
                onclick_attr = anchor_tag.get('onclick')
                if onclick_attr:
                    url_start_index = onclick_attr.find("'") + 1
                    url_end_index = onclick_attr.rfind("'")
                    onclick_url = onclick_attr[url_start_index:url_end_index]
                    onclick_urls.append(URL_BASE + onclick_url)
                    with open("url.txt", "a") as f:
                        f.write(URL_BASE + onclick_url + "\n")
                    Path()
                    print(onclick_url)
        with open(done_path, "a") as f:
            f.write(url + "\n")

    
def download_html(url):

    response = requests.get(url)
    if response.status_code == 200:
        return response.text


def parse_index(html):

    soup = BeautifulSoup(html, 'html.parser')
    # Find all table rows

    # Find the table
    table = soup.find('table')

    # Extract table headers
    headers = [th.text.strip() for th in table.find_all('th')]

    # Extract table rows
    data = []
    for tr in table.find_all('tr'):
        row = []
        for td in tr.find_all('td'):
            # If there is a link in the cell, extract the href attribute
            link = td.find('a')
            if not link:
                row.append(td.text.strip())
            else:
                link = URL_BASE + link['href'].lstrip(".")
                row.append(link)

        if row:
            data.append(row)

    # Create DataFrame
    df = pd.DataFrame(data, columns=headers)
    df = df.rename(columns={df.columns[0]: 'url'})
    return df


    

def slugify(filename):
    return "".join( x for x in filename if (x.isalnum() or x in ",._- ()#@%&!"))

    
        
if __name__ == "__main__":
    main()
